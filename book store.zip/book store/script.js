searchform = document.querySelector('.search-form')
document.querySelector('#search-btn').onclick = () => {
    searchform.classList.toggle('active');
}
/*......login form....*/
var loginform = document.querySelector('.login-form-container');
document.querySelector('#login-btn').onclick = () => {
    loginform.classList.toggle('active');
}
document.querySelector('#close-login-btn').onclick = () => {  
    loginform.classList.remove('active');
}

/*......swiper home section......*/
var swiper = new Swiper('.books-list', {
    loop: true,
    centeredSlides: true,
    autoplay: {
        delay: 9500,
        disableOnInteraction: false,
    },
    mousewheel: {
        invert: false,
    },
    breakpoints: {
        0: {
            slidesPerView: 1,
        },
        768: {
            slidesPerView: 2,
        },
        1024: {
            slidesPerView: 3,
        },
    },
});

/*........featured section start...*/
// document.addEventListener('DOMContentLoaded', function () {
    var featuredSwiper = new Swiper('.featured-slider', {
        loop: true,
        centeredSlides: false,
        autoplay: {
            delay: 9500,
            disableOnInteraction: false,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        mousewheel: {
            invert: true,
        },
        breakpoints: {
            0: {
                slidesPerView: 1,
            },
            450: {
                slidesPerView: 2,
            },
            768: {
                slidesPerView: 3,
            },
            1024: {
                slidesPerView: 4,
            },
        },
    });



document.addEventListener("DOMContentLoaded", function() {
    var swiper = new Swiper('.swiper-container', {
        loop: true,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev'
        },
        autoplay: {
            delay: 3000,
        },
        effect: 'fade',
    });
});
